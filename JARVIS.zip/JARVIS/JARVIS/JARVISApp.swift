//
//  JARVISApp.swift
//  JARVIS
//
//  Created by Aditya Saravana on 1/25/21.
//

import SwiftUI

@main
struct JARVISApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
